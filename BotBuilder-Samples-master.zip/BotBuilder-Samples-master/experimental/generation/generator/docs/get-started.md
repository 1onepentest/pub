To use this package please see: [Using dialog:generate](../../docs/get-started.md).

To work with this package:
1) `npm install`
2) `npm run build`
3) `npm run test`
4) Open the folder in Visual Studio Code and debug.

Pull requests and contributions are welcome!