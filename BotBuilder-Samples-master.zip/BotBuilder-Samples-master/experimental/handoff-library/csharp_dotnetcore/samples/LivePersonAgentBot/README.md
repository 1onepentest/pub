# LivePerson Agent Bot

This sample demonstrates how to connect any Bot Framework channel to the LivePerson agent hub using the
"bot as an agent" approach. The bot uses the new Bot Framework Handoff APIs.

See http://aka.ms/bfhandoff for details

