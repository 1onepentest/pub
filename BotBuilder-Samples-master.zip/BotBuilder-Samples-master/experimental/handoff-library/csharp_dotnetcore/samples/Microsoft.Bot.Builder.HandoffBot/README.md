# EchoBot
Bot Framework Handoff bot sample.

This bot has been created using Bot Framework, it shows how to create a simple bot that initiates handoff to an agent upon user's request

