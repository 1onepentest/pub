# Adaptive dialog

Documentation and samples for Adaptive dialogs have been re-organized. Please refer to links below. 

| Language     | Availability          | Docs         | Samples      |
|--------------|-----------------------|--------------|--------------|
| csharp       | Generally available   | [here][1]    | [here][2]    |
| javascript   | Preview               | [here][1]    | [here][3]    |
| python       | Not available         | N/A          | N/A          |
| java         | Not available         | N/A          | N/A          |

[1]:https://aka.ms/adaptive-dialogs
[2]:https://aka.ms/adaptive-dialogs-csharp-samples
[3]:https://aka.ms/adaptive-dialogs-js-samples